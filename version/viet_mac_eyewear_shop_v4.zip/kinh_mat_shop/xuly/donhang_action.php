<?php
require_once 'functions.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// =========================================================================
// 1. ĐẶT HÀNG & THANH TOÁN TỪ POPUP KHÁCH HÀNG (HỖ TRỢ QR TECHCOMBANK & COD)
// =========================================================================
if ($action === 'checkout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_SESSION['cart'])) {
        $_SESSION['err'] = "Giỏ hàng của bạn đang trống!";
        header("Location: ../index.php?tab=shop-view");
        exit;
    }

    $tenNN = trim($_POST['tenNN'] ?? '');
    $soDienThoai = trim($_POST['soDienThoai'] ?? '');
    $diaChi = trim($_POST['diaChi'] ?? '');
    $phuongThuc = $_POST['phuongThuc'] ?? 'Chuyển khoản QR';
    $voucherCode = strtoupper(trim($_POST['voucherCode'] ?? ''));

    if ($tenNN === '' || $soDienThoai === '' || $diaChi === '') {
        $_SESSION['err'] = "Vui lòng điền đầy đủ Họ tên, Số điện thoại và Địa chỉ nhận hàng!";
        header("Location: ../index.php?tab=cart-view");
        exit;
    }

    try {
        $conn->beginTransaction();

        // Tính tổng tiền hàng
        $tongTamTinh = 0;
        foreach ($_SESSION['cart'] as $item) {
            $donGiaUnit = (float)$item['giaGong'] + (float)$item['giaTrong'];
            $tongTamTinh += $donGiaUnit * (int)$item['soLuong'];
        }

        // Kiểm tra & áp dụng Voucher nếu có
        $maVoucher = null;
        $soTienGiam = 0;
        if ($voucherCode !== '') {
            $stmtVC = $conn->prepare("SELECT * FROM VOUCHER WHERE code = ? FOR UPDATE");
            $stmtVC->execute([$voucherCode]);
            $vc = $stmtVC->fetch();

            if ($vc && new DateTime($vc['ngayHetHan']) > new DateTime() &&
                ($vc['gioiHanDung'] === null || $vc['daDung'] < $vc['gioiHanDung']) &&
                $tongTamTinh >= (float)$vc['donHangToiThieu']) {

                $maVoucher = $vc['maVoucher'];
                if ($vc['loaiGiam'] === 'Phần trăm' || $vc['loaiGiam'] === '%') {
                    $soTienGiam = round($tongTamTinh * ((float)$vc['giaTriGiam'] / 100));
                } else {
                    $soTienGiam = (float)$vc['giaTriGiam'];
                }
                if ($soTienGiam > $tongTamTinh) $soTienGiam = $tongTamTinh;
            }
        }

        $tongThanhToan = max(0, $tongTamTinh - $soTienGiam);
        $maKH = layMaKhachHangHienTai($conn);
        $maDH = taoMaTuDong($conn, 'DONHANG', 'maDonHang', 'DH');

        // 1.1. Tạo bản ghi DONHANG
        $conn->prepare("INSERT INTO DONHANG (maDonHang, maKhachHang, maVoucher, ngayDat, tongTien, tenNN, soDienThoai, diaChi) 
                        VALUES (?, ?, ?, NOW(), ?, ?, ?, ?)")
             ->execute([$maDH, $maKH, $maVoucher, $tongThanhToan, $tenNN, $soDienThoai, $diaChi]);

        // 1.2. Tạo các bản ghi CHITIETDONHANG & đảm bảo giữ chỗ tồn kho (soLuongDat)
        foreach ($_SESSION['cart'] as $item) {
            $donGiaUnit = (float)$item['giaGong'] + (float)$item['giaTrong'];
            $qty = (int)$item['soLuong'];

            // Nếu chưa khóa tồn kho qua AJAX thì khóa ngay tại đây
            if (empty($_SESSION['stock_locked'])) {
                $conn->prepare("UPDATE TONKO SET soLuongDat = soLuongDat + ? WHERE maSanPham = ?")
                     ->execute([$qty, $item['maSanPham']]);
            }

            for ($q = 0; $q < $qty; $q++) {
                $maCTDH = taoMaTuDong($conn, 'CHITIETDONHANG', 'maCTDDonHang', 'CTDH');
                $conn->prepare("INSERT INTO CHITIETDONHANG (maCTDDonHang, maDonHang, maSanPham, maTrongKinh, donGia) 
                                VALUES (?, ?, ?, ?, ?)")
                     ->execute([$maCTDH, $maDH, $item['maSanPham'], $item['maTrongKinh'], $donGiaUnit]);
            }
        }

        // 1.3. Tạo bản ghi THANHTOAN
        $maTT = taoMaTuDong($conn, 'THANHTOAN', 'maThanhToan', 'TT');
        $trangThaiTT = ($phuongThuc === 'Chuyển khoản QR') ? 'Chờ xác nhận thanh toán' : 'Chờ xác nhận đơn';
        $conn->prepare("INSERT INTO THANHTOAN (maThanhToan, maDonHang, phuongThuc, trangThai, soTien) 
                        VALUES (?, ?, ?, ?, ?)")
             ->execute([$maTT, $maDH, $phuongThuc, $trangThaiTT, $tongThanhToan]);

        // 1.4. Ghi LICHSUVOUCHER & tăng daDung nếu có dùng Voucher
        if ($maVoucher !== null) {
            $maLSV = taoMaTuDong($conn, 'LICHSUVOUCHER', 'maLichSu', 'LSV');
            $conn->prepare("INSERT INTO LICHSUVOUCHER (maLichSu, maVoucher, maDonHang, ngayDung) VALUES (?, ?, ?, NOW())")
                 ->execute([$maLSV, $maVoucher, $maDH]);
            $conn->prepare("UPDATE VOUCHER SET daDung = daDung + 1 WHERE maVoucher = ?")->execute([$maVoucher]);
        }

        // 1.5. Dọn sạch giỏ hàng trong DB & Session
        if ($maKH) {
            $stmtGH = $conn->prepare("SELECT maGioHang FROM GIOHANG WHERE maKhachHang = ? LIMIT 1");
            $stmtGH->execute([$maKH]);
            $maGH = $stmtGH->fetchColumn();
            if ($maGH) {
                $conn->prepare("DELETE FROM CHITIETGIOHANG WHERE maGioHang = ?")->execute([$maGH]);
            }
        }

        $conn->commit();
        unset($_SESSION['cart']);
        unset($_SESSION['stock_locked']);

        if ($phuongThuc === 'Chuyển khoản QR') {
            $_SESSION['msg'] = "Đặt hàng [$maDH] thành công! Hệ thống đã ghi nhận chuyển khoản QR của bạn và đang chờ Nhân viên/Admin xác nhận thanh toán.";
        } else {
            $_SESSION['msg'] = "Đặt hàng COD [$maDH] thành công! Việt MAC sẽ sớm liên hệ xác nhận và tiến hành mài lắp kính.";
        }
        header("Location: ../index.php?tab=customer-orders");
        exit;
    } catch (Exception $e) {
        if ($conn->inTransaction()) $conn->rollBack();
        $_SESSION['err'] = "Lỗi xử lý đơn hàng: " . $e->getMessage();
        header("Location: ../index.php?tab=cart-view");
        exit;
    }
}

// =========================================================================
// 2. NHÂN VIÊN / ADMIN XÁC NHẬN THANH TOÁN & DUYỆT ĐƠN (TRỪ TỒN KHO THỰC)
// =========================================================================
if ($action === 'confirm_payment') {
    if (!isStaffOrAdmin()) {
        $_SESSION['err'] = "Bạn không có quyền xác nhận thanh toán!";
        header("Location: ../index.php");
        exit;
    }

    $maDH = $_GET['id'] ?? '';
    try {
        $conn->beginTransaction();

        $stmtTT = $conn->prepare("SELECT trangThai FROM THANHTOAN WHERE maDonHang = ? FOR UPDATE");
        $stmtTT->execute([$maDH]);
        $currentStatus = $stmtTT->fetchColumn();

        if ($currentStatus && in_array($currentStatus, ['Chờ xác nhận thanh toán', 'Chờ xác nhận đơn'])) {
            // Cập nhật trạng thái thành Đã thanh toán
            $conn->prepare("UPDATE THANHTOAN SET trangThai = 'Đã thanh toán' WHERE maDonHang = ?")->execute([$maDH]);

            // Trừ tồn kho vật lý (soLuong) và nhả giữ chỗ (soLuongDat)
            $stmtItems = $conn->prepare("SELECT maSanPham, COUNT(*) AS qty FROM CHITIETDONHANG WHERE maDonHang = ? GROUP BY maSanPham");
            $stmtItems->execute([$maDH]);
            foreach ($stmtItems->fetchAll() as $row) {
                $conn->prepare("UPDATE TONKO 
                                SET soLuong = GREATEST(0, soLuong - ?), 
                                    soLuongDat = GREATEST(0, soLuongDat - ?) 
                                WHERE maSanPham = ?")
                     ->execute([(int)$row['qty'], (int)$row['qty'], $row['maSanPham']]);
            }
            $_SESSION['msg'] = "Đã xác nhận thanh toán & duyệt đơn hàng [$maDH] thành công! Tồn kho đã được cập nhật.";
        } else {
            $_SESSION['err'] = "Đơn hàng [$maDH] đã được xử lý trước đó.";
        }

        $conn->commit();
    } catch (Exception $e) {
        if ($conn->inTransaction()) $conn->rollBack();
        $_SESSION['err'] = "Lỗi xác nhận đơn: " . $e->getMessage();
    }
    header("Location: ../index.php?tab=admin-orders");
    exit;
}

// =========================================================================
// 3. CẬP NHẬT TRẠNG THÁI GIA CÔNG / GIAO VẬN / HỦY ĐƠN (NHÂN VIÊN & ADMIN)
// =========================================================================
if ($action === 'update_status' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isStaffOrAdmin()) {
        $_SESSION['err'] = "Bạn không có quyền cập nhật trạng thái đơn hàng!";
        header("Location: ../index.php");
        exit;
    }

    $maDH = $_POST['maDonHang'] ?? '';
    $newStatus = $_POST['trangThaiDon'] ?? '';

    try {
        $conn->beginTransaction();

        $stmtTT = $conn->prepare("SELECT trangThai FROM THANHTOAN WHERE maDonHang = ? FOR UPDATE");
        $stmtTT->execute([$maDH]);
        $oldStatus = $stmtTT->fetchColumn();

        if ($oldStatus && $oldStatus !== $newStatus) {
            $conn->prepare("UPDATE THANHTOAN SET trangThai = ? WHERE maDonHang = ?")->execute([$newStatus, $maDH]);

            $stmtItems = $conn->prepare("SELECT maSanPham, COUNT(*) AS qty FROM CHITIETDONHANG WHERE maDonHang = ? GROUP BY maSanPham");
            $stmtItems->execute([$maDH]);
            $items = $stmtItems->fetchAll();

            // Nếu chuyển từ Chờ xác nhận sang trạng thái đã duyệt -> trừ tồn thực & giảm giữ tạm
            if (in_array($oldStatus, ['Chờ xác nhận thanh toán', 'Chờ xác nhận đơn']) &&
                in_array($newStatus, ['Đã thanh toán', 'Đang mài lắp', 'Đang giao hàng', 'Đã giao'])) {
                foreach ($items as $row) {
                    $conn->prepare("UPDATE TONKO SET soLuong = GREATEST(0, soLuong - ?), soLuongDat = GREATEST(0, soLuongDat - ?) WHERE maSanPham = ?")
                         ->execute([(int)$row['qty'], (int)$row['qty'], $row['maSanPham']]);
                }
            }

            // Nếu hủy đơn
            if ($newStatus === 'Đã hủy') {
                if (in_array($oldStatus, ['Chờ xác nhận thanh toán', 'Chờ xác nhận đơn'])) {
                    // Chỉ nhả giữ tạm soLuongDat
                    foreach ($items as $row) {
                        $conn->prepare("UPDATE TONKO SET soLuongDat = GREATEST(0, soLuongDat - ?) WHERE maSanPham = ?")
                             ->execute([(int)$row['qty'], $row['maSanPham']]);
                    }
                } else {
                    // Hoàn lại tồn vật lý soLuong
                    foreach ($items as $row) {
                        $conn->prepare("UPDATE TONKO SET soLuong = soLuong + ? WHERE maSanPham = ?")
                             ->execute([(int)$row['qty'], $row['maSanPham']]);
                    }
                }
            }
        }

        $conn->commit();
        $_SESSION['msg'] = "Đã cập nhật trạng thái đơn [$maDH] thành '$newStatus'.";
    } catch (Exception $e) {
        if ($conn->inTransaction()) $conn->rollBack();
        $_SESSION['err'] = "Lỗi cập nhật trạng thái: " . $e->getMessage();
    }
    header("Location: ../index.php?tab=admin-orders");
    exit;
}

// =========================================================================
// 4. TẠO ĐƠN HÀNG TẠI CỬA HÀNG (POS) CHO NHÂN VIÊN & ADMIN
// Khi xác nhận -> Đã thanh toán luôn & trừ tồn kho thực ngay lập tức!
// =========================================================================
if ($action === 'create_pos_order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isStaffOrAdmin()) {
        $_SESSION['err'] = "Chỉ Nhân viên hoặc Admin mới được tạo đơn tại cửa hàng!";
        header("Location: ../index.php");
        exit;
    }

    $loaiKhach = $_POST['loaiKhach'] ?? 'member';
    $maKH = null;
    $tenNN = '';
    $soDienThoai = '';
    $diaChi = trim($_POST['diaChi'] ?? 'Mua trực tiếp tại cửa hàng Việt MAC');
    if ($diaChi === '') $diaChi = 'Mua trực tiếp tại cửa hàng Việt MAC';

    if ($loaiKhach === 'member' && !empty($_POST['maKhachHang'])) {
        $maKH = $_POST['maKhachHang'];
        $stmtKH = $conn->prepare("SELECT kh.soDienThoai, kh.diaChi, nd.hoTen 
                                  FROM KHACHHANG kh JOIN NGUOIDUNG nd ON kh.maNguoiDung = nd.maNguoiDung 
                                  WHERE kh.maKhachHang = ? LIMIT 1");
        $stmtKH->execute([$maKH]);
        $khRow = $stmtKH->fetch();
        if ($khRow) {
            $tenNN = $khRow['hoTen'];
            $soDienThoai = $khRow['soDienThoai'];
            if (!empty($khRow['diaChi'])) $diaChi = $khRow['diaChi'];
        }
    } else {
        $tenNN = trim($_POST['tenNN'] ?? '');
        $soDienThoai = trim($_POST['soDienThoai'] ?? '');
    }

    $maSPList = $_POST['maSanPham'] ?? [];
    $maTKList = $_POST['maTrongKinh'] ?? [];
    $qtyList  = $_POST['soLuong'] ?? [];
    $voucherCode = strtoupper(trim($_POST['voucherCode'] ?? ''));
    $phuongThuc = $_POST['phuongThuc'] ?? 'Tiền mặt tại quầy';

    if ($tenNN === '' || $soDienThoai === '' || empty($maSPList)) {
        $_SESSION['err'] = "Vui lòng nhập thông tin khách hàng và chọn ít nhất 1 sản phẩm!";
        header("Location: ../index.php?tab=admin-pos");
        exit;
    }

    try {
        $conn->beginTransaction();

        $tongTamTinh = 0;
        $orderLines = [];

        for ($i = 0; $i < count($maSPList); $i++) {
            $msp = $maSPList[$i];
            $mtk = $maTKList[$i] ?? '';
            $qty = max(1, (int)($qtyList[$i] ?? 1));
            if ($msp === '') continue;

            // Kiểm tra tồn kho thực
            $stmtSP = $conn->prepare("SELECT sp.tenSanPham, sp.gia, COALESCE(tk.soLuong, 0) AS soLuong, COALESCE(tk.soLuongDat, 0) AS soLuongDat
                                      FROM SANPHAM sp LEFT JOIN TONKO tk ON sp.maSanPham = tk.maSanPham
                                      WHERE sp.maSanPham = ? FOR UPDATE");
            $stmtSP->execute([$msp]);
            $sp = $stmtSP->fetch();

            if (!$sp || ($sp['soLuong'] - $sp['soLuongDat']) < $qty) {
                $conn->rollBack();
                $_SESSION['err'] = "Sản phẩm [" . ($sp['tenSanPham'] ?? $msp) . "] không đủ số lượng tồn kho khả dụng!";
                header("Location: ../index.php?tab=admin-pos");
                exit;
            }

            $giaTrong = 0;
            $validMTK = null;
            if ($mtk !== '') {
                $stmtLens = $conn->prepare("SELECT gia FROM TRONGKINH WHERE maTrongKinh = ? LIMIT 1");
                $stmtLens->execute([$mtk]);
                $lensRow = $stmtLens->fetch();
                if ($lensRow) {
                    $giaTrong = (float)$lensRow['gia'];
                    $validMTK = $mtk;
                }
            }

            $donGiaUnit = (float)$sp['gia'] + $giaTrong;
            $tongTamTinh += $donGiaUnit * $qty;
            $orderLines[] = [
                'maSanPham'   => $msp,
                'maTrongKinh' => $validMTK,
                'donGia'      => $donGiaUnit,
                'soLuong'     => $qty
            ];
        }

        if (empty($orderLines)) {
            $conn->rollBack();
            $_SESSION['err'] = "Chưa có sản phẩm hợp lệ trong đơn!";
            header("Location: ../index.php?tab=admin-pos");
            exit;
        }

        // Kiểm tra Voucher nếu có
        $maVoucher = null;
        $soTienGiam = 0;
        if ($voucherCode !== '') {
            $stmtVC = $conn->prepare("SELECT * FROM VOUCHER WHERE code = ? FOR UPDATE");
            $stmtVC->execute([$voucherCode]);
            $vc = $stmtVC->fetch();
            if ($vc && new DateTime($vc['ngayHetHan']) > new DateTime() &&
                ($vc['gioiHanDung'] === null || $vc['daDung'] < $vc['gioiHanDung']) &&
                $tongTamTinh >= (float)$vc['donHangToiThieu']) {
                $maVoucher = $vc['maVoucher'];
                if ($vc['loaiGiam'] === 'Phần trăm' || $vc['loaiGiam'] === '%') {
                    $soTienGiam = round($tongTamTinh * ((float)$vc['giaTriGiam'] / 100));
                } else {
                    $soTienGiam = (float)$vc['giaTriGiam'];
                }
                if ($soTienGiam > $tongTamTinh) $soTienGiam = $tongTamTinh;
            }
        }

        $tongThanhToan = max(0, $tongTamTinh - $soTienGiam);
        $maDH = taoMaTuDong($conn, 'DONHANG', 'maDonHang', 'DH');

        // Tạo DONHANG
        $conn->prepare("INSERT INTO DONHANG (maDonHang, maKhachHang, maVoucher, ngayDat, tongTien, tenNN, soDienThoai, diaChi) 
                        VALUES (?, ?, ?, NOW(), ?, ?, ?, ?)")
             ->execute([$maDH, $maKH, $maVoucher, $tongThanhToan, $tenNN, $soDienThoai, $diaChi]);

        // Tạo CHITIETDONHANG & trừ trực tiếp tồn kho thực (soLuong)
        foreach ($orderLines as $line) {
            for ($q = 0; $q < $line['soLuong']; $q++) {
                $maCTDH = taoMaTuDong($conn, 'CHITIETDONHANG', 'maCTDDonHang', 'CTDH');
                $conn->prepare("INSERT INTO CHITIETDONHANG (maCTDDonHang, maDonHang, maSanPham, maTrongKinh, donGia) 
                                VALUES (?, ?, ?, ?, ?)")
                     ->execute([$maCTDH, $maDH, $line['maSanPham'], $line['maTrongKinh'], $line['donGia']]);
            }
            $conn->prepare("UPDATE TONKO SET soLuong = GREATEST(0, soLuong - ?) WHERE maSanPham = ?")
                 ->execute([$line['soLuong'], $line['maSanPham']]);
        }

        // Tạo THANHTOAN ở trạng thái 'Đã thanh toán' luôn!
        $maTT = taoMaTuDong($conn, 'THANHTOAN', 'maThanhToan', 'TT');
        $conn->prepare("INSERT INTO THANHTOAN (maThanhToan, maDonHang, phuongThuc, trangThai, soTien) 
                        VALUES (?, ?, ?, 'Đã thanh toán', ?)")
             ->execute([$maTT, $maDH, $phuongThuc, $tongThanhToan]);

        if ($maVoucher !== null) {
            $maLSV = taoMaTuDong($conn, 'LICHSUVOUCHER', 'maLichSu', 'LSV');
            $conn->prepare("INSERT INTO LICHSUVOUCHER (maLichSu, maVoucher, maDonHang, ngayDung) VALUES (?, ?, ?, NOW())")
                 ->execute([$maLSV, $maVoucher, $maDH]);
            $conn->prepare("UPDATE VOUCHER SET daDung = daDung + 1 WHERE maVoucher = ?")->execute([$maVoucher]);
        }

        $conn->commit();
        $_SESSION['msg'] = "Tạo đơn tại cửa hàng [$maDH] cho khách [$tenNN] thành công! Trạng thái: Đã thanh toán.";
    } catch (Exception $e) {
        if ($conn->inTransaction()) $conn->rollBack();
        $_SESSION['err'] = "Lỗi tạo đơn tại quầy: " . $e->getMessage();
    }
    header("Location: ../index.php?tab=admin-orders");
    exit;
}

// =========================================================================
// 5. KHÁCH HÀNG GỬI ĐÁNH GIÁ SẢN PHẨM (BẢNG DANHGIA)
// =========================================================================
if ($action === 'submit_review' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $maKH = layMaKhachHangHienTai($conn);
    if (!$maKH) {
        $_SESSION['err'] = "Vui lòng đăng nhập tài khoản khách hàng để gửi đánh giá!";
        header("Location: ../index.php");
        exit;
    }

    $maSP = $_POST['maSanPham'] ?? '';
    $sao = max(1, min(5, (int)($_POST['sao'] ?? 5)));
    $binhLuan = trim($_POST['binhLuan'] ?? '');

    // Kiểm tra khách đã mua sản phẩm này chưa
    $checkBought = $conn->prepare("SELECT COUNT(*) 
                                   FROM CHITIETDONHANG ct 
                                   JOIN DONHANG dh ON ct.maDonHang = dh.maDonHang 
                                   WHERE dh.maKhachHang = ? AND ct.maSanPham = ?");
    $checkBought->execute([$maKH, $maSP]);

    if ($checkBought->fetchColumn() == 0) {
        $_SESSION['err'] = "Bạn chỉ có thể đánh giá sản phẩm sau khi đã đặt mua sản phẩm này!";
        header("Location: ../index.php?tab=shop-view");
        exit;
    }

    $maDG = taoMaTuDong($conn, 'DANHGIA', 'maDanhGia', 'DG');
    $conn->prepare("INSERT INTO DANHGIA (maDanhGia, maSanPham, maKhachHang, sao, binhLuan) VALUES (?, ?, ?, ?, ?)")
         ->execute([$maDG, $maSP, $maKH, $sao, $binhLuan]);

    $_SESSION['msg'] = "Cảm ơn bạn đã gửi đánh giá $sao sao cho sản phẩm!";
    header("Location: ../index.php?tab=shop-view");
    exit;
}
?>
